M_inv = vesselABC.Minv([1 2 6], [1 2 6]);
D = [2.6486e5 0 0;
     0 8.8164e5 0;
     0 0 3.3774e8];

wave_period = 13;
wave_freq = 2*pi/wave_period;
diag_natwavefreq = diag([wave_freq, wave_freq, wave_freq]);
diag_reldampratios = diag([0.05, 0.05, 0.1]);

Aw = [zeros(3) eye(3); -diag_natwavefreq^2 -2*diag_reldampratios*diag_natwavefreq];
Cw = [zeros(3) eye(3)];

zeta_ni = 1.0;
lambda = 0.1;

omega_peak = [0.9 0.9 0.9];
omega_cutoff = [1.1 1.1 1.1];

k1  = -2*(zeta_ni - lambda)*omega_cutoff(1)/omega_peak(1);
k2  = -2*(zeta_ni - lambda)*omega_cutoff(2)/omega_peak(2);
k3  = -2*(zeta_ni - lambda)*omega_cutoff(3)/omega_peak(3);

k4  =  2*omega_cutoff(1)*(zeta_ni - lambda);
k5  =  2*omega_cutoff(2)*(zeta_ni - lambda);
k6  =  2*omega_cutoff(3)*(zeta_ni - lambda);

k7  =  omega_cutoff(1);
k8  =  omega_cutoff(2);
k9  =  omega_cutoff(3);

K1 = [ diag([k1 k2 k3]);
       diag([k4 k5 k6]) ];

K2 = diag([k7 k8 k9]);

K4 = 100000 * diag([ 1 1 100]);
K3 = 0.1*K4;

T = diag([10000, 10000, 100]);

K3 ./ K4;
1 ./ T;